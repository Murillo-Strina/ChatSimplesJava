import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;
import java.awt.KeyEventDispatcher;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ClientGui extends JFrame {
    private JTextField messageField;
    private JTextArea chatArea;
    private JButton sendButton, clearButton, exitButton;
    private Socket clientSocket;
    private PrintStream output;
    private Scanner input;
    private int clientId;

    public ClientGui() {
        setTitle("Cliente de Chat");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(70, 70, 70));

        setupMessageField();
        setupChatArea();
        setupButtonPanel();

        addKeyDispatcher();

        try {
            connectToServer();
            new Thread(this::listenForMessages).start();
        } catch (IOException e) {
            chatArea.append("Erro ao conectar ao servidor ou limite de conexões atingido.\n");
            disableButtons();
        }        

        setVisible(true);
    }

    private void setupMessageField() {
        messageField = new JTextField();
        messageField.setBackground(new Color(70, 70, 70));
        messageField.setForeground(Color.WHITE);
        messageField.setCaretColor(Color.WHITE);
        messageField.addActionListener(e -> sendMessage());
        add(messageField, BorderLayout.NORTH);
    }

    private void setupChatArea() {
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setBackground(new Color(70, 70, 70));
        chatArea.setForeground(Color.WHITE);
        add(new JScrollPane(chatArea), BorderLayout.CENTER);
    }

    private void setupButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(new Color(70, 70, 70));

        sendButton = createStyledButton("Enviar");
        sendButton.addActionListener(e -> sendMessage());

        clearButton = createStyledButton("Limpar");
        clearButton.addActionListener(e -> chatArea.setText(""));

        exitButton = createStyledButton("Sair");
        exitButton.addActionListener(e -> {
            disconnect();
            System.exit(0);
        });

        buttonPanel.add(sendButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(exitButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(new Color(122, 122, 122));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void addKeyDispatcher() {
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(new KeyEventDispatcher() {
            @Override
            public boolean dispatchKeyEvent(KeyEvent e) {
                if (e.getID() == KeyEvent.KEY_PRESSED && e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    disconnect();
                    System.exit(0);
                }
                return false;
            }
        });
    }

    private void connectToServer() throws IOException {
        clientSocket = new Socket(Server.address, Server.port);
        output = new PrintStream(clientSocket.getOutputStream());
        input = new Scanner(clientSocket.getInputStream());

        if (input.hasNextLine()) {
            String serverMessage = input.nextLine();
            if (serverMessage.startsWith("ID:")) {
                clientId = Integer.parseInt(serverMessage.substring(3).trim());
                chatArea.append("Conectado como Usuário " + clientId + "\n");
            } else if (serverMessage.equals("LIMIT_REACHED")) {
                chatArea.append("Limite de conexões atingido. Você não pode enviar mensagens.\n");
                disableButtons();
            }
        }
    }

    private void sendMessage() {
        String message = messageField.getText().trim();
        if (!message.isEmpty()) {
            output.println(message);
            chatArea.append("Usuário " + clientId + ": " + message + "\n");
            messageField.setText("");
        }
    }

    private void listenForMessages() {
        while (input.hasNextLine()) {
            String message = input.nextLine();
            chatArea.append(message + "\n");
        }
    }

    private void disconnect() {
        try {
            if (clientSocket != null && !clientSocket.isClosed()) {
                output.close();
                input.close();
                clientSocket.close();
                chatArea.append("Você foi desconectado do servidor.\n");
            }
        } catch (IOException e) {
            chatArea.append("Erro ao desconectar.\n");
        }
    }

    private void disableButtons() {
        sendButton.setEnabled(false);
        clearButton.setEnabled(false);
        exitButton.setEnabled(false);
        messageField.setEditable(false);
    }
}
