public class TestChat {
    public static void main(String[] args) {
        new ClientGui();
    }
}
