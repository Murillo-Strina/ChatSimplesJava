import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;

public class Server {
    public static final String address = "127.0.0.1";
    public static final int port = 3334;
    private static int clientCounter = 1;
    private static ServerSocket server;
    private static final Set<ClientHandler> clients = new HashSet<>();
    private static final Queue<Integer> availableIds = new LinkedList<>();

    public static void main(String[] args) {
        System.out.println("===== INICIANDO SERVIDOR =====");
        try {
            startServer();
            while (true) {
                Socket clientSocket = server.accept();

                synchronized (clients) {
                    if (clients.size() >= 2) {
                        rejectConnection(clientSocket);
                        continue;
                    }
                }

                ClientHandler clientHandler = new ClientHandler(clientSocket);
                synchronized (clients) {
                    clients.add(clientHandler);
                    logConnection(clientHandler);
                }
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            endServer();
        }
    }

    private static void startServer() throws IOException {
        server = new ServerSocket(port);
        System.out.println("Servidor iniciado na porta " + port);
    }

    private static void rejectConnection(Socket clientSocket) throws IOException {
        PrintStream output = new PrintStream(clientSocket.getOutputStream());
        output.println("LIMIT_REACHED");
        clientSocket.close();
    }

    private static void logConnection(ClientHandler clientHandler) {
        System.out.println("Usuário " + clientHandler.getClientId() + " conectou. Clientes conectados: " + clients.size());
    }

    private static void broadcastMessage(String message, ClientHandler sender) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                if (client != sender) {
                    client.sendMessage(message);
                }
            }
        }
    }

    private static void notifyAllClients(String message) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                client.sendMessage(message);
            }
        }
    }

    private static void endServer() {
        try {
            if (server != null) {
                server.close();
                System.out.println("Servidor encerrado.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;
        private Scanner input;
        private PrintStream output;
        private final int clientId;

        public ClientHandler(Socket socket) throws IOException {
            synchronized (clients) {
                this.clientId = !availableIds.isEmpty() ? availableIds.poll() : clientCounter++;
            }

            this.clientSocket = socket;
            this.input = new Scanner(clientSocket.getInputStream());
            this.output = new PrintStream(clientSocket.getOutputStream());
            output.println("ID: " + clientId);
            notifyAllClients("Usuário " + clientId + " conectou.");
        }

        @Override
        public void run() {
            try {
                while (input.hasNextLine()) {
                    String message = input.nextLine();
                    broadcastMessage("Usuário " + clientId + ": " + message, this);
                }
            } finally {
                closeConnection();
            }
        }

        public void sendMessage(String message) {
            output.println(message);
        }

        private void closeConnection() {
            try {
                if (input != null) input.close();
                if (output != null) output.close();
                if (clientSocket != null) clientSocket.close();

                synchronized (clients) {
                    clients.remove(this);
                    availableIds.add(clientId);
                    notifyAllClients("Usuário " + clientId + " saiu do chat.");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public int getClientId() {
            return clientId;
        }
    }
}
